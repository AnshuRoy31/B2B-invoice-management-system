# Creating Flask api

## How to run

1. Install python 3.8
2. Jupyter Notebook / Anconda
3. Install the libraries specially Flask
4. Run the code

### We will get some api calls in the postman and those api we will integrate in frontend react app