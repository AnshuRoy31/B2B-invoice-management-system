# Creating the model

## How to run

1. Install python 3.8
2. Jupyter Notebook / Anconda
3. Install the libraries
4. Run the code

## Output

- Get a `model.sav` file in the current directory. We can use this file to load the model in the Flask Integration.
- Get a .csv file in the current directory. Which contains the predictions.