# MySql database

This is a demo dataset provided by Highradius for created the Backend

## Steps to use

Install MySql workbench and Run both files

## Output

It will create the database and tables
The databse name is `grey_goose` and the tables are `business`, `customer`, `winter_internship`