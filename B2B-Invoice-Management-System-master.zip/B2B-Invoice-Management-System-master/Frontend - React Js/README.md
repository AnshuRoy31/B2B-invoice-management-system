# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm install`

To install all the dependencies from `package.json` to run the project.

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

### ***To see the whole project you have to downlode all the folder to specific directory and run them well***

## Output 

Find all the output images in [Screen Shots](https://github.com/sambitos23/B2B-Invoice-Management-System/tree/master/Frontend%20-%20React%20Js/Screen%20Shots) folder.